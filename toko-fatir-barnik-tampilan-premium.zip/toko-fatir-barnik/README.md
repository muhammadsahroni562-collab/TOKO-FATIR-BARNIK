TOKO FATIR BARNIK — WEBSITE VERSI PENGEMBANGAN

FITUR:
- Tampilan responsif untuk HP dan komputer.
- Katalog, pencarian, kategori, harga, stok, dan foto melalui URL.
- Keranjang belanja dan checkout ke WhatsApp.
- Panel admin untuk tambah, edit, dan hapus produk.
- Catatan pesanan lokal, status pesanan, dan tombol tindak lanjut WhatsApp.
- Ekspor/impor katalog produk JSON.
- Kontak WhatsApp toko: 089682006784.

MULAI:
1. Buka index.html di browser untuk menguji website.
2. Tekan tombol Admin. Kode awal: 123456.
3. Untuk GitHub Pages, unggah index.html ke repositori `toko-fatir-barnik` dan aktifkan Pages dari branch utama/root.
4. Sebelum digunakan sungguhan, ganti contoh produk, harga, stok, dan foto.

BATASAN PENTING:
Versi ini adalah website statis. Produk, kode admin, dan catatan pesanan disimpan di localStorage browser, sehingga tidak tersinkron ke perangkat lain dan bukan sistem admin aman. Tombol checkout mengirim detail pesanan melalui WhatsApp; pembayaran QRIS otomatis belum diaktifkan. Database online, login admin yang aman, stok/pesanan lintas perangkat, dan pembayaran otomatis memerlukan backend/database, konfigurasi hosting, serta akun merchant/payment gateway. Jangan masukkan rahasia API atau kredensial ke file HTML publik.


PENYEGARAN TAMPILAN:
Tema visual diperbarui dengan warna biru-putih dan aksen emas, kartu produk lebih rapi, tombol lebih menonjol, latar lebih lembut, serta tampilan yang tetap responsif untuk layar ponsel.
